/**
 * stats.js
 * Computes today's total, weekly total, and streak.
 */

const Stats = (() => {
  function refresh() {
    const today = new Date();
    const todayStr = _dateStr(today);

    // Today total (include live session)
    const liveSecs  = Timer.isRunning() ? Timer.getSeconds() : 0;
    const todaySecs = Storage.getSeconds(todayStr) + liveSecs;
    document.getElementById('todayTotal').textContent = _fmt(Math.floor(todaySecs / 60));

    // This week total (Mon–Sun)
    let weekMins = Math.floor(liveSecs / 60);
    for (let i = 0; i < 7; i++) {
      const d = new Date(today);
      d.setDate(today.getDate() - i);
      const s = _dateStr(d);
      if (s !== todayStr) weekMins += Math.floor(Storage.getSeconds(s) / 60);
    }
    weekMins += Math.floor(Storage.getSeconds(todayStr) / 60);
    document.getElementById('weekTotal').textContent = _fmt(weekMins);

    // Streak (consecutive days with > 0 seconds)
    let streak = 0;
    const checkDate = new Date(today);
    while (true) {
      const s = _dateStr(checkDate);
      const secs = Storage.getSeconds(s) + (s === todayStr ? liveSecs : 0);
      if (secs > 0) {
        streak++;
        checkDate.setDate(checkDate.getDate() - 1);
      } else {
        break;
      }
    }
    document.getElementById('streakCount').textContent = streak;
  }

  function _fmt(mins) {
    if (mins >= 60) {
      const h = Math.floor(mins / 60);
      const m = mins % 60;
      return m > 0 ? `${h}h${m}m` : `${h}h`;
    }
    return `${mins}m`;
  }

  function _dateStr(date) {
    return date.toISOString().split('T')[0];
  }

  return { refresh };
})();
