/**
 * app.js
 * Entry point — initializes all modules on DOMContentLoaded.
 */

document.addEventListener('DOMContentLoaded', () => {
  Calendar.render();
  Stats.refresh();
  Goal.init();

  // Live stats update every second while timer runs
  setInterval(() => {
    if (Timer.isRunning()) {
      Stats.refresh();
      Goal.refresh();
    }
  }, 1000);
});
