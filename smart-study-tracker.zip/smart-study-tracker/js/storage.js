/**
 * storage.js
 * Centralized localStorage helpers for Smart Study Tracker.
 */

const Storage = (() => {
  const PREFIX = 'sst_';

  function key(date) {
    return PREFIX + date; // e.g. sst_2026-06-15
  }

  /** Save seconds for a given date string (YYYY-MM-DD). Adds to existing. */
  function addSeconds(dateStr, secs) {
    const existing = getSeconds(dateStr);
    localStorage.setItem(key(dateStr), existing + secs);
  }

  /** Get seconds stored for a given date string. */
  function getSeconds(dateStr) {
    return parseInt(localStorage.getItem(key(dateStr))) || 0;
  }

  /** Get daily goal in minutes. */
  function getGoal() {
    return parseInt(localStorage.getItem(PREFIX + 'goal')) || 0;
  }

  /** Set daily goal in minutes. */
  function setGoal(minutes) {
    localStorage.setItem(PREFIX + 'goal', minutes);
  }

  /** Get all stored date keys (YYYY-MM-DD strings). */
  function getAllDates() {
    const dates = [];
    for (let i = 0; i < localStorage.length; i++) {
      const k = localStorage.key(i);
      if (k && k.startsWith(PREFIX) && k !== PREFIX + 'goal') {
        dates.push(k.replace(PREFIX, ''));
      }
    }
    return dates;
  }

  /** Clear all study data (but not goal). */
  function clearAll() {
    getAllDates().forEach(d => localStorage.removeItem(key(d)));
  }

  return { addSeconds, getSeconds, getGoal, setGoal, getAllDates, clearAll };
})();
