/**
 * goal.js (included in app.js namespace as Goal)
 * Handles daily goal setting and progress bar.
 */

const Goal = (() => {
  function init() {
    const saved = Storage.getGoal();
    if (saved) document.getElementById('goalInput').value = saved;
    refresh();
  }

  function save() {
    const input = document.getElementById('goalInput');
    const mins  = parseInt(input.value);
    if (!mins || mins < 1) {
      document.getElementById('goalStatus').textContent = 'Please enter a valid number of minutes.';
      return;
    }
    Storage.setGoal(mins);
    refresh();
    Calendar.render(); // update goal-met highlights
  }

  function refresh() {
    const goal = Storage.getGoal();
    const bar  = document.getElementById('progressBar');
    const status = document.getElementById('goalStatus');

    if (!goal) {
      bar.style.width = '0%';
      status.textContent = 'No goal set yet.';
      return;
    }

    const todayStr  = new Date().toISOString().split('T')[0];
    const liveSecs  = Timer.isRunning() ? Timer.getSeconds() : 0;
    const todayMins = Math.floor((Storage.getSeconds(todayStr) + liveSecs) / 60);
    const pct       = Math.min(100, Math.round((todayMins / goal) * 100));

    bar.style.width = pct + '%';

    if (pct >= 100) {
      status.textContent = `🎉 Goal reached! ${todayMins}/${goal} min — amazing!`;
      bar.style.background = '#00c785';
    } else {
      const remaining = goal - todayMins;
      status.textContent = `${todayMins}/${goal} min (${pct}%) — ${remaining} min to go`;
      bar.style.background = '#00c785';
    }
  }

  return { init, save, refresh };
})();

function saveGoal() { Goal.save(); }
