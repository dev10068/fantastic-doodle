/**
 * timer.js
 * Handles the stopwatch logic.
 */

const Timer = (() => {
  let seconds = 0;
  let interval = null;
  let running = false;
  let startTimestamp = null;

  function getSeconds() { return seconds; }
  function isRunning() { return running; }

  function start() {
    if (running) return;
    running = true;
    startTimestamp = Date.now() - seconds * 1000;
    interval = setInterval(_tick, 500);
    _updateDisplay();
    _updateBtn(true);
    document.getElementById('sessionStatus').textContent =
      'Session started at ' + new Date().toLocaleTimeString();
  }

  function stop() {
    if (!running) return;
    clearInterval(interval);
    running = false;
    // Save to storage
    const today = _todayStr();
    Storage.addSeconds(today, seconds);
    seconds = 0;
    _updateDisplay();
    _updateBtn(false);
    document.getElementById('sessionStatus').textContent =
      'Session saved ✓ — keep it up!';
    // Refresh UI
    if (typeof Stats !== 'undefined') Stats.refresh();
    if (typeof Calendar !== 'undefined') Calendar.render();
    if (typeof Goal !== 'undefined') Goal.refresh();
  }

  function reset() {
    if (running) { clearInterval(interval); running = false; }
    seconds = 0;
    _updateDisplay();
    _updateBtn(false);
    document.getElementById('sessionStatus').textContent = 'Session not started';
  }

  function toggle() {
    running ? stop() : start();
  }

  function _tick() {
    seconds = Math.round((Date.now() - startTimestamp) / 1000);
    _updateDisplay();
  }

  function _updateDisplay() {
    const h = Math.floor(seconds / 3600).toString().padStart(2, '0');
    const m = Math.floor((seconds % 3600) / 60).toString().padStart(2, '0');
    const s = (seconds % 60).toString().padStart(2, '0');
    document.getElementById('display').textContent = `${h}:${m}:${s}`;
  }

  function _updateBtn(active) {
    const btn = document.getElementById('mainBtn');
    if (active) {
      btn.textContent = '⏹ Stop & Save';
      btn.className = 'btn btn-stop';
    } else {
      btn.textContent = '▶ Start Study';
      btn.className = 'btn btn-start';
    }
  }

  function _todayStr() {
    return new Date().toISOString().split('T')[0];
  }

  return { start, stop, reset, toggle, isRunning, getSeconds };
})();

// Global wrappers for onclick attributes
function toggleTimer() { Timer.toggle(); }
function resetTimer()  { Timer.reset(); }
