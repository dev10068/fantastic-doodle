/**
 * calendar.js
 * Renders the monthly calendar with study time per day.
 */

const Calendar = (() => {
  let viewDate = new Date();

  function render() {
    const cal = document.getElementById('calendar');
    cal.innerHTML = '';

    const year  = viewDate.getFullYear();
    const month = viewDate.getMonth();
    const today = new Date();
    const goal  = Storage.getGoal(); // minutes

    document.getElementById('monthYear').textContent =
      viewDate.toLocaleString('default', { month: 'long', year: 'numeric' });

    // Blank cells for first day of month offset
    const firstDay = new Date(year, month, 1).getDay();
    for (let i = 0; i < firstDay; i++) {
      const blank = document.createElement('div');
      blank.className = 'day empty-day';
      cal.appendChild(blank);
    }

    const daysInMonth = new Date(year, month + 1, 0).getDate();

    for (let d = 1; d <= daysInMonth; d++) {
      const dateStr = `${year}-${_pad(month + 1)}-${_pad(d)}`;
      const savedSecs = Storage.getSeconds(dateStr);
      const savedMins = Math.floor(savedSecs / 60);

      const div = document.createElement('div');
      div.className = 'day';

      const isToday =
        d === today.getDate() &&
        month === today.getMonth() &&
        year === today.getFullYear();

      if (isToday) div.classList.add('today');
      if (savedMins > 0) div.classList.add('has-data');
      if (goal > 0 && savedMins >= goal) div.classList.add('goal-met');

      const label = savedMins > 0
        ? `<small>${savedMins >= 60
            ? Math.floor(savedMins / 60) + 'h' + (savedMins % 60 ? (savedMins % 60) + 'm' : '')
            : savedMins + 'm'}</small>`
        : '<small>—</small>';

      div.innerHTML = `${d}${label}`;
      div.title = `${dateStr}: ${savedMins} min studied`;
      div.addEventListener('click', () => _showDayDetail(dateStr, savedMins));
      cal.appendChild(div);
    }
  }

  function changeMonth(step) {
    viewDate.setMonth(viewDate.getMonth() + step);
    render();
  }

  function _showDayDetail(dateStr, mins) {
    const hours = Math.floor(mins / 60);
    const rem   = mins % 60;
    const timeStr = hours > 0 ? `${hours}h ${rem}m` : `${mins}m`;
    alert(`📅 ${dateStr}\n⏱ Study time: ${timeStr}`);
  }

  function _pad(n) { return n.toString().padStart(2, '0'); }

  return { render, changeMonth };
})();

// Global wrapper for onclick
function changeMonth(step) { Calendar.changeMonth(step); }
