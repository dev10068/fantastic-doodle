# 📚 Smart Study Tracker

A clean, dark-themed study timer with a monthly calendar heatmap, streak counter, weekly stats, and daily goal tracking — all running in the browser with no backend needed.

![Smart Study Tracker](assets/preview.png)

## ✨ Features

- ⏱ **Stopwatch Timer** — Start, stop, and save study sessions
- 📅 **Monthly Calendar** — See how much you studied on each day
- 🔥 **Streak Counter** — Tracks consecutive days of studying
- 📊 **Weekly Stats** — Today + this week totals at a glance
- 🎯 **Daily Goal** — Set a minute target and track progress live
- 💾 **Offline / No backend** — Everything saved in `localStorage`

## 🚀 Quick Start

### Option 1 — Open directly
Just open `index.html` in any modern browser. No server needed.

### Option 2 — GitHub Pages
1. Fork or clone this repo
2. Go to **Settings → Pages**
3. Set source to `main` branch, `/ (root)`
4. Your tracker will be live at `https://yourusername.github.io/smart-study-tracker`

### Option 3 — Local dev server
```bash
# Python
python -m http.server 8080

# Node (npx)
npx serve .
```
Then open `http://localhost:8080`.

## 📁 Project Structure

```
smart-study-tracker/
├── index.html          # Main page
├── css/
│   └── style.css       # All styles
├── js/
│   ├── storage.js      # localStorage helpers
│   ├── timer.js        # Stopwatch logic
│   ├── calendar.js     # Monthly calendar renderer
│   ├── stats.js        # Today / week / streak calculator
│   ├── goal.js         # Daily goal + progress bar
│   └── app.js          # Entry point (initializes everything)
└── assets/
    └── favicon.svg
```

## 🛠 Tech Stack

- Vanilla HTML, CSS, JavaScript
- `localStorage` for persistence
- Zero dependencies, zero build step

## 📱 Mobile Friendly

Fully responsive — works on phones and tablets.

## 🤝 Contributing

PRs welcome! Some ideas for contributions:

- [ ] Export data as CSV
- [ ] Dark/light theme toggle
- [ ] Pomodoro mode
- [ ] Subject tagging per session
- [ ] Charts (weekly bar graph)

## 📄 License

MIT — do whatever you want with it.
